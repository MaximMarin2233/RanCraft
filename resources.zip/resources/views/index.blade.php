<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>RanCraft</title>
{{--    <script type="text/javascript">--}}
{{--        var onloadCallback = function() {--}}
{{--            grecaptcha.render('html_element', {--}}
{{--                'sitekey' : '6LecwV4pAAAAAKRmEeQ6wN82B5CrOXezC1lE6-xf'--}}
{{--            });--}}
{{--        };--}}
{{--    </script>--}}

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    @vite('resources/js/app.js')
</head>
<body>
    <div id="app">
    </div>

{{--    <script src="https://unpkg.com/vue-recaptcha@latest/dist/vue-recaptcha.min.js"></script>--}}
{{--    <script src="https://www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit"--}}
{{--            async defer>--}}
{{--    </script>--}}
{{--    <script src="https://www.google.com/recaptcha/api.js?onload=vueRecaptchaApiLoaded&render=explicit" async defer></script>--}}
</body>
</html>


