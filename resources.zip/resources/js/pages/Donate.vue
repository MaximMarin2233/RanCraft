<template>
    <h1>Donate</h1>
</template>

<script lang="ts">
import {defineComponent} from "vue";

export default defineComponent({
    components: {},
    setup() {
        return {};
    }
});
</script>

<style lang="less" scoped>

</style>
