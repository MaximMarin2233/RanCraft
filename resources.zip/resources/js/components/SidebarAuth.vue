<template>
    <aside class="aside-auth" v-if="!token">
        <h2 class="aside-auth__title">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M24 24C27.3137 24 30 21.3137 30 18C30 14.6863 27.3137 12 24 12C20.6863 12 18 14.6863 18 18C18 21.3137 20.6863 24 24 24Z"
                    stroke="#1C274C" stroke-width="3" />
                <path d="M35.9382 40C35.62 34.217 33.8494 30 23.9998 30C14.1504 30 12.3798 34.217 12.0615 40"
                    stroke="#1C274C" stroke-width="3" stroke-linecap="round" />
                <path
                    d="M14 6.67564C16.9417 4.97394 20.3572 4 24 4C35.0456 4 44 12.9543 44 24C44 35.0456 35.0456 44 24 44C12.9543 44 4 35.0456 4 24C4 20.3572 4.97394 16.9417 6.67564 14"
                    stroke="#1C274C" stroke-width="3" stroke-linecap="round" />
            </svg>

            Авторизация
        </h2>

        <input v-model="nick" type="text" placeholder="Логин" class="aside-auth__input">
        <input v-model="password" type="password" placeholder="Пароль" class="aside-auth__input">
        <input @click.prevent="login" type="submit" value="ВОЙТИ" class="aside-auth__btn">

        <div class="aside-auth__links">
            <ul class="header__menu nav">
                <li class="nav-item">
                    <router-link class="aside-auth__link" to="/reg">Регистрация</router-link>
                </li>
                <li class="nav-item">
                    <router-link class="aside-auth__link" to="#">Забыли пароль?</router-link>
                </li>
            </ul>
        </div>

    </aside>
    <aside class="aside-auth" v-if="token">
        <h2 class="aside-auth__title">
            <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M24 24C27.3137 24 30 21.3137 30 18C30 14.6863 27.3137 12 24 12C20.6863 12 18 14.6863 18 18C18 21.3137 20.6863 24 24 24Z"
                    stroke="#1C274C" stroke-width="3" />
                <path d="M35.9382 40C35.62 34.217 33.8494 30 23.9998 30C14.1504 30 12.3798 34.217 12.0615 40"
                    stroke="#1C274C" stroke-width="3" stroke-linecap="round" />
                <path
                    d="M14 6.67564C16.9417 4.97394 20.3572 4 24 4C35.0456 4 44 12.9543 44 24C44 35.0456 35.0456 44 24 44C12.9543 44 4 35.0456 4 24C4 20.3572 4.97394 16.9417 6.67564 14"
                    stroke="#1C274C" stroke-width="3" stroke-linecap="round" />
            </svg>

            <div class="aside-auth__title-text">
                <span>Профиль</span>
                <span data-nickname>{{ nick }}</span>
            </div>
        </h2>

        <ul class="header__menu nav nav-pills">
            <li class="nav-item">
                <router-link class="nav-link" to="/profile">Профиль</router-link>
            </li>
            <li class="nav-item">
                <router-link class="nav-link" to="/donate">Донат</router-link>
            </li>
            <li class="nav-item">
                <a @click.prevent="logout" class="nav-link" href="#">Выйти</a>
            </li>
        </ul>

    </aside>
</template>

<script lang="ts">
import { defineComponent } from "vue";
import axios from "axios";

export default defineComponent({
    name: "Login",
    components: {},
    setup() {
        return {};
    },
    methods: {
        login() {
            axios.get('/sanctum/csrf-cookie').then(response => {
                axios.post('/login', { nick: this.nick, password: this.password })
                    .then(r => {
                        localStorage.setItem('x_xsrf_token', r.config.headers['X-XSRF-TOKEN'])
                        this.$router.push({ name: 'home' })
                        this.$forceUpdate()
                    })
                    .catch(err => {
                    })
            })
        },
        logout() {
            axios.post('/logout')
                .then(res => {
                    localStorage.removeItem('x_xsrf_token')
                    this.$router.push({ name: 'home' })
                    this.$forceUpdate()

                })
        },
        getToken() {
            this.token = localStorage.getItem('x_xsrf_token')
        },
    },
    data() {
        return {
            //email: null,
            nick: null,
            password: null,
            token: null
        }
    },

    mounted() {

        this.getToken()
    },
    updated() {

        this.getToken()
    },
});
</script>

<style>
.aside-auth {
    max-width: 350px;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 25px;
    gap: 15px;
}

.aside-auth__title {
    color: #18333E;
    font-size: 28px;
    font-weight: 500;
    line-height: normal;
    display: flex;
    gap: 10px;
    margin: 0;
}

.aside-auth__title-text {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.aside-auth__links {
    width: 100%;
}

.aside-auth__links ul {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
}

.aside-auth__link {
    color: #18333E;
    font-size: 16px;
    font-weight: 500;
    line-height: normal;
}

.aside-auth__input {
    padding: 10px 15px;
    border-radius: 26.5px;
    background-color: #E9F1FA;
    color: #18333E;
    text-align: center;
    font-size: 16px;
    font-weight: 400;
    line-height: normal;
    border: 1px solid #18333E;
    width: 100%;
}

.aside-auth__btn {
    border-radius: 30.5px;
    background: #18333E;
    padding: 15px;
    color: #FFF;
    text-align: center;
    font-size: 18px;
    font-weight: 700;
    line-height: normal;
    border: none;
    width: 100%;
}
</style>
