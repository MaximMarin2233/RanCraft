<template>

</template>

<script>
export default {
    name: "Personal"
}
</script>

<style scoped>

</style>
